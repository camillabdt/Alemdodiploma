# Verificação da entrega · 3 nov. 2026

- Interface React compilada para distribuição com Vite; pacote já inclui frontend/dist.
- Suíte Python: 80 testes passaram, 7 omitidos por dependerem da base real ausente.
- Contratos exercitados: importação válida/inválida, filtros, recortes bloqueados, isolamento entre sessões, expiração/encerramento, exportações PDF/HTML/Markdown/CSV/JSON, cálculo XAI e cache.
- XAI: referência de AUC 0,5, métricas dentro do domínio esperado, aditividade, alvos/classes insuficientes e ausência de linhas individuais no resultado.
- Relatório usa as taxas protegidas da API e identifica base fictícia/importada. Resultado XAI é exportado separadamente, com parâmetros e hash da base.
- Dados e indicadores do estudo real não foram reavaliados nesta migração.
- O teste `scripts/testar_fluxo_http.py` inicia um servidor Uvicorn real e verifica importação da base fictícia, filtros, cinco exportações, XAI, aditividade, exportação XAI, encerramento e permissão/rejeição de origens CORS.
- A interface também foi compilada com subdiretório `/Alemdodiploma/` e API externa para conferir a configuração do GitHub Pages. O endereço utilizado nesse build foi apenas de teste; não existe uma API publicada nesta etapa.
- O gerador do formulário passou na simulação das 43 especificações, matrizes, desvios e idempotência. Não foi executado na conta Google da pesquisadora.
- A inspeção visual em navegador permanece pendente: a prévia gerenciada não tinha o ambiente Python e a instalação local do Chromium recebeu um download inválido. A compilação e os testes HTTP não equivalem a esse teste visual.
- Os testes automatizados não substituem pré-teste e avaliação com coordenadores. Ver docs/AVALIACAO_PLATAFORMA_XAI.md.

requirements-verificado.txt registra as versões diretas efetivamente testadas. requirements.txt mantém faixas de compatibilidade para instalação em diferentes versões de Python; para reproduzir o experimento, use as versões verificadas e o mesmo arquivo-base.

O workflow de verificação automatiza esses testes. A publicação no Pages é manual e depende de uma API HTTPS disponível. O CSV real e os gabaritos reservados não integram o repositório público.
