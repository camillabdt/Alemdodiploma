"""Confere o destino antes de publicar a interface. Não envia dados de egressos."""
import json
import os
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

origin = os.environ['API_ORIGIN'].strip().rstrip('/')
parsed = urlsplit(origin)
if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or
        parsed.password or parsed.path or parsed.query or parsed.fragment):
    raise SystemExit('Informe somente a origem HTTPS da API, sem caminho, credenciais ou /api.')
pages = os.environ['PAGES_ORIGIN'].rstrip('/')
with urlopen(origin + '/api/health', timeout=30) as response:
    health = json.load(response)
if health.get('status') != 'ok' or health.get('application') != 'Alumni View':
    raise SystemExit('O destino não respondeu como uma API Alumni View disponível.')
request = Request(origin + '/api/dashboard', method='OPTIONS', headers={
    'Origin': pages, 'Access-Control-Request-Method': 'POST',
    'Access-Control-Request-Headers': 'authorization,content-type'})
with urlopen(request, timeout=30) as response:
    if response.headers.get('Access-Control-Allow-Origin') != pages:
        raise SystemExit('Configure ALUMNI_ALLOWED_ORIGINS com a origem do GitHub Pages.')
print('API disponível e acesso da interface autorizado. Nenhum CSV foi enviado.')
