#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f frontend/dist/index.html ]; then
  printf '%s\n' 'Interface compilada ausente. Execute npm --prefix frontend ci e npm run build.'
  exit 1
fi
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt
printf '%s\n' 'Abra http://localhost:8000. Para encerrar: Ctrl+C.'
exec .venv/bin/python -m uvicorn api.main:app --host 127.0.0.1 --port 8000
