# Best, esta é a versão React + XAI

1. Extraia o ZIP em uma pasta NOVA, para não misturar arquivos da versão anterior.
2. Abra a pasta que contém este arquivo e iniciar.sh.
3. Clique com o botão direito, escolha Abrir no terminal e execute:

```bash
bash iniciar.sh
```

4. Espere a instalação terminar e abra http://localhost:8000 no navegador.
5. Mantenha o terminal aberto. Para encerrar, use Ctrl+C.

A interface compilada já está incluída: você não precisa de Node para simplesmente abrir e usar o pacote.

A demonstração usa dados fictícios. Para analisar seus dados, vá a Base de dados e importe o CSV no formato esperado. No menu Laboratório XAI, escolha o indicador e clique em Calcular e comparar.

Esta versão substitui a interface anterior e não tem busca de pessoas, campo de chave ou integração com buscador. O foco é a plataforma analítica e a interpretação dos modelos.

Os documentos docs/METODO_XAI.md e docs/AVALIACAO_PLATAFORMA_XAI.md explicam o método e o ajuste proposto para avaliar a nova prioridade do TCC. Não são resultados de avaliação com coordenadores.
