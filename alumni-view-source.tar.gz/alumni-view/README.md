# Alumni View · Além do Diploma

Plataforma de análise de trajetórias e explicabilidade para coordenações de graduação. Versão 3: interface React, API Python/FastAPI e laboratório XAI. Não utiliza Streamlit, API de busca ou chave de serviço externo.

Para clonar do GitHub, testar e preparar o `github.io`, consulte [Publicação](docs/PUBLICACAO.md). O GitHub Pages precisa de uma API hospedada separadamente para executar o XAI. O questionário e seu gerador estão em [avaliacao](avaliacao/COMO_CRIAR_FORMS_V3.md).

## Executar no Ubuntu

O pacote de entrega inclui a interface já compilada. Extraia o ZIP, abra o terminal na pasta que contém este README e execute:

```bash
bash iniciar.sh
```

Abra **http://localhost:8000**. Para encerrar, pressione Ctrl+C no terminal. O script cria um ambiente Python e instala as dependências na primeira execução. É necessário Python 3.10 ou superior, suporte a `venv` e internet para instalar os pacotes. Não é necessário Node para utilizar o pacote compilado.

Se o sistema informar que o módulo venv não está disponível:

```bash
sudo apt install python3-venv
bash iniciar.sh
```

No Windows, execute `iniciar.bat` com Python instalado. Em qualquer sistema, a alternativa manual é criar um ambiente virtual, instalar requirements.txt e iniciar `python -m uvicorn api.main:app --host 127.0.0.1 --port 8000`.

## Começar a análise

1. O painel abre com 280 registros **fictícios**, identificados como demonstração. Eles não representam os resultados do TCC.
2. Em **Base de dados**, baixe o modelo ou importe seu CSV preparado, sem nomes, empresas ou URLs.
3. Se conhecer a população institucional por curso, informe os totais nos campos opcionais; a cobertura só é calculada com esse denominador.
4. Explore filtros, categorias e indicadores nas páginas analíticas.
5. Abra **Laboratório XAI**, selecione liderança, progressão ou empreendedorismo e clique em **Calcular e comparar**.
6. Leia as métricas antes de interpretar as contribuições. Exporte o relatório agregado do recorte ou a análise XAI separadamente.

Os quatro indicadores devem estar previamente codificados. A plataforma não localiza pessoas nem coleta experiências profissionais. O módulo de busca foi removido desta versão.

## Laboratório XAI

- Modelos: regressão logística e random forest; referência DummyClassifier baseada na prevalência do treino.
- Avaliação: AUC ROC, precisão média (AP) e Brier; cinco partições estratificadas e três repetições, semente 2026.
- Pré-processamento: categorias e agrupamento de valores raros definidos no treino; padronização da regressão dentro do pipeline.
- Explicações: valores de Shapley exatos por quatro fatores, em registros fora do treino, na primeira repetição. O fundo tem até 24 registros do treino de cada partição. Contribuições são agregadas; não há classificação individual na API.
- Fatores: curso, tempo desde a conclusão, UF de nascimento e tipo de instituição. Nome, ID, gênero e categoria do cargo não entram como preditores.
- Limites operacionais: 30 a 1.000 registros, com pelo menos dez registros em cada classe do indicador selecionado. São escolhas desta implementação, não um cálculo de suficiência estatística universal.
- A aditividade das contribuições é verificada numericamente. A exportação JSON inclui métricas, parâmetros, versões e hash da base.

As contribuições descrevem os modelos, não causas das trajetórias. O desvio entre partições não é um intervalo de confiança. Consulte docs/METODO_XAI.md.

## Dados e sessão

O CSV é enviado à API local e fica em memória, isolado por token de sessão. Expira após quatro horas ou ao reiniciar o servidor; a ação Encerrar descarta a sessão. Não é gravado no navegador ou no repositório. O arquivo original deve ser guardado pela coordenação.

CSV: até 5 MB e 10.000 registros no painel; limite menor para o XAI. Nomes, URLs, empresas e cargos literais não integram o esquema. Não inserir identificadores em campos de categoria. Colunas extras, IDs duplicados e indicadores diferentes de 0/1 são recusados. `Ano_de_Conclusao + Tempo_desde_Conclusao` precisa resultar no mesmo ano de referência em todos os registros.

Recortes abaixo de dez registros são bloqueados. Grupos abaixo de cinco e células binárias complementares pequenas são suprimidos; há supressão complementar nas distribuições e explicações por grupo. Essas medidas não são uma garantia formal contra ataques por diferença entre consultas. A distribuição é para uso local e restrito; não há autenticação institucional ou isolamento persistente entre organizações para hospedagem pública.

## Desenvolvimento

A interface usa React e Vite. Para alterar e recompilar (Node 22 ou superior):

```bash
npm --prefix frontend ci
npm run build
```

Para desenvolvimento com recarga automática, crie primeiro .venv e instale requirements.txt. Depois execute `npm run dev` e abra o endereço informado pelo Vite. Em produção local, `bash iniciar.sh` serve API e interface compilada no mesmo endereço.

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
```

Também há Dockerfile e compose.yaml: `docker compose up --build`, com porta 8000 limitada ao computador local.

## Estrutura

- frontend/src: interface React, filtros, importação e laboratório.
- api/main.py: sessões, validação, agregados, exportação e cálculo XAI.
- app/core: leitura e métodos analíticos independentes da interface.
- pipeline: preparação da base e codebook, sem geração de secrets.
- data/exemplo: base fictícia versionada; bases reais permanecem fora do repositório.
- tests: testes de contratos da API, dados, estatística, XAI, relatórios e auditoria.

O trabalho empírico original utiliza dados públicos profissionais e registros institucionais. A remoção da busca do produto não altera retroativamente as fontes da pesquisa.
