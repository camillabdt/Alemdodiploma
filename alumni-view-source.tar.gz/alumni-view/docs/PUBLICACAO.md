# Publicação da plataforma

O repositório contém React e uma API Python/FastAPI. GitHub Pages serve somente os arquivos da interface; não executa os modelos Python. Documentação: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Testar no próprio computador a partir do GitHub

Requer Python 3.10 ou superior e Node 22 ou superior para compilar a interface:

```bash
git clone https://github.com/camillabdt/Alemdodiploma.git
cd Alemdodiploma
npm --prefix frontend ci
npm run build
bash iniciar.sh
```

Abra http://localhost:8000. O CSV da pesquisa é importado pela interface; não deve ser adicionado ao repositório público. O teste técnico disponível em `scripts/testar_fluxo_http.py` utiliza exclusivamente a base fictícia.

## Hospedagem completa

### Render gratuito

O arquivo `render.yaml` prepara um único Web Service com Docker, plano `free`, porta 8000 e health check `/api/health`. Não cria banco ou disco pago. Os deploys automáticos ficam desativados para preservar a versão avaliada.

É necessário primeiro enviar esta versão React/FastAPI ao repositório autorizado. O código antigo do repositório não deve ser usado no deploy. Na conta Render conectada, criar o serviço a partir desta revisão; confirmar plano Free, Dockerfile na raiz e aguardar o health check. Só considerar publicado quando houver URL respondendo e os fluxos forem testados nessa URL.

O plano gratuito tem limites de memória, CPU e suspensão por inatividade. O cálculo XAI com o CSV definitivo precisa ser testado nesse ambiente antes da aplicação com coordenadores. Reiniciar o serviço perde as sessões em memória; o CSV precisará ser importado novamente.

O Dockerfile compila a interface e executa a API no mesmo serviço, na porta 8000. Essa opção permite publicar a plataforma inteira em um servidor com suporte a Docker, sem separar interface e API. Use HTTPS no acesso externo.

Antes de utilizar dados reais remotamente, a hospedagem deve estar definida no protocolo de guarda e acesso. A aplicação possui tokens temporários, limite de sessões e supressão de grupos pequenos, mas não possui autenticação institucional. As respostas ficam na memória de um único processo; mantenha um worker, pois não há armazenamento compartilhado entre workers. Não publicar o CSV no GitHub.

## Interface no github.io e API em servidor separado

1. Hospede a API em um serviço Python ou Docker. Confirme que `https://SEU-SERVIDOR/api/health` responde com `status: ok` e `application: Alumni View`.
2. Na API, configure `ALUMNI_ALLOWED_ORIGINS=https://camillabdt.github.io`. A origem não inclui `/Alemdodiploma/`. Isso controla o navegador; não é autenticação ou bloqueio de acesso direto à API.
3. No repositório, abra **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Em **Actions → Publicar interface no GitHub Pages → Run workflow**, informe somente a origem HTTPS da API, sem `/api`.
5. O workflow testa a disponibilidade da API e sua permissão de acesso antes de compilar e publicar. A URL esperada é `https://camillabdt.github.io/Alemdodiploma/`; ela só estará disponível após uma publicação bem-sucedida.
6. Faça um teste no navegador com a base autorizada: importar CSV, aplicar filtros, calcular XAI e baixar os dois tipos de relatório. Só depois preencha `URL_FERRAMENTA` no script do formulário e gere o rascunho.

O workflow de publicação é manual. Sem um endereço de API, não se deve publicar uma interface incapaz de realizar o teste. A verificação automática da plataforma é independente e roda em pushes e pull requests.
