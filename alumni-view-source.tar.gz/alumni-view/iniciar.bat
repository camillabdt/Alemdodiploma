@echo off
cd /d "%~dp0"
if not exist frontend\dist\index.html (
  echo Interface compilada ausente. Execute npm --prefix frontend ci e npm run build.
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  python -m venv .venv
  if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
echo Abra http://localhost:8000. Para encerrar: Ctrl+C.
.venv\Scripts\python.exe -m uvicorn api.main:app --host 127.0.0.1 --port 8000
